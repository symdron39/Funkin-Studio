/* ============================================================
   runtime/runtime.js — V-Slice の演出スクリプト（SongEvent / Module）を動かす、軽量なゲーム環境
   ------------------------------------------------------------
   ・HScript（hscript.js）に「それっぽい FlxG / PlayState / FlxSprite / FlxTween ...」を渡して、
     .hxc のイベントやモジュールを実際に実行する。画面に出るもの（スプライト・テキスト・フィルター）は
     3 つのカメラ（camGame / camHUD / camCutscene）に描く。
   ・本物の V-Slice ではないので、再現しているのは「演出に使われやすい API」だけ。
     ない API は「スタブ」（何を呼んでも落ちない代役）になり、使われたものが warnings に集まる。
   ・軽量化: ・描画は 1280×720 の仮想座標を縮尺する 2D キャンバス描画  ・シェーダーを持つカメラだけ WebGL を通す
     ・画面外 / alpha 0 のものは描かない  ・Tween は 1 本のリストを 1 回なめるだけ
   ============================================================ */
import { findSound } from "../services/FunkinAssets.js";
import { HScript, HMap, makeStub } from "./hscript.js";
import { GLPost, GLSL_GRAYSCALE, Quality } from "./glpost.js";
import { FlxRuntimeShader, shaderInit, shaderMethods, makeAdjustColorShader, makeRainShader, makeNativeShader, NATIVE_SHADERS, makeMosaicEffect } from "./shader.js";
import { loadImage, parseSparrowXml } from "../states/stage/sparrowAtlas.js";

const LAYER_MAX_W = 1280; // フィルターを掛けるカメラの絵の最大幅(px)
export const GAME_W = 1280,
  GAME_H = 720;

// ---------------------------------------------------------------- イージング（Flixel の FlxEase と同じ式）
const A = 1,
  P = 0.4,
  S = (P / (2 * Math.PI)) * Math.asin(1 / A);
const bounceOut = (t) => {
  if (t < 1 / 2.75) return 7.5625 * t * t;
  if (t < 2 / 2.75) return 7.5625 * (t -= 1.5 / 2.75) * t + 0.75;
  if (t < 2.5 / 2.75) return 7.5625 * (t -= 2.25 / 2.75) * t + 0.9375;
  return 7.5625 * (t -= 2.625 / 2.75) * t + 0.984375;
};
const smoothInOut = (t) => t * t * (t * -2 + 3);
const smootherInOut = (t) => t * t * t * (t * (t * 6 - 15) + 10);
export const FlxEase = {
  linear: (t) => t,
  quadIn: (t) => t * t,
  quadOut: (t) => -t * (t - 2),
  quadInOut: (t) => (t <= 0.5 ? t * t * 2 : 1 - --t * t * 2),
  cubeIn: (t) => t * t * t,
  cubeOut: (t) => 1 + --t * t * t,
  cubeInOut: (t) => (t <= 0.5 ? t * t * t * 4 : 1 + --t * t * t * 4),
  quartIn: (t) => t * t * t * t,
  quartOut: (t) => 1 - (t -= 1) * t * t * t,
  quartInOut: (t) => (t <= 0.5 ? t * t * t * t * 8 : (1 - (t = t * 2 - 2) * t * t * t) / 2 + 0.5),
  quintIn: (t) => t * t * t * t * t,
  quintOut: (t) => (t = t - 1) * t * t * t * t + 1,
  quintInOut: (t) => (t <= 0.5 ? t * t * t * t * t * 16 : ((t = t * 2 - 2) * t * t * t * t + 2) / 2),
  sineIn: (t) => -Math.cos((Math.PI / 2) * t) + 1,
  sineOut: (t) => Math.sin((Math.PI / 2) * t),
  sineInOut: (t) => -Math.cos(Math.PI * t) / 2 + 0.5,
  bounceIn: (t) => 1 - bounceOut(1 - t),
  bounceOut,
  bounceInOut: (t) => (t < 0.5 ? (1 - bounceOut(1 - t * 2)) / 2 : bounceOut(t * 2 - 1) / 2 + 0.5),
  circIn: (t) => -(Math.sqrt(1 - t * t) - 1),
  circOut: (t) => Math.sqrt(1 - (t - 1) * (t - 1)),
  circInOut: (t) => (t <= 0.5 ? (Math.sqrt(1 - t * t * 4) - 1) / -2 : (Math.sqrt(1 - (t * 2 - 2) * (t * 2 - 2)) + 1) / 2),
  expoIn: (t) => Math.pow(2, 10 * (t - 1)),
  expoOut: (t) => -Math.pow(2, -10 * t) + 1,
  expoInOut: (t) => (t < 0.5 ? Math.pow(2, 10 * (t * 2 - 1)) / 2 : (-Math.pow(2, -10 * (t * 2 - 1)) + 2) / 2),
  backIn: (t) => t * t * (2.70158 * t - 1.70158),
  backOut: (t) => 1 - --t * t * (-2.70158 * t - 1.70158),
  backInOut: (t) => ((t *= 2) < 1 ? (t * t * (2.70158 * t - 1.70158)) / 2 : (1 - (t -= 2) * t * (-2.70158 * t - 1.70158)) / 2 + 0.5),
  elasticIn: (t) => -(A * Math.pow(2, 10 * (t -= 1)) * Math.sin(((t - S) * (2 * Math.PI)) / P)),
  elasticOut: (t) => A * Math.pow(2, -10 * t) * Math.sin(((t - S) * (2 * Math.PI)) / P) + 1,
  elasticInOut: (t) => (t < 0.5 ? -0.5 * (A * Math.pow(2, 10 * (t = t * 2 - 1)) * Math.sin(((t - S) * (2 * Math.PI)) / (P * 1.5))) : A * Math.pow(2, -10 * (t = t * 2 - 1)) * Math.sin(((t - S) * (2 * Math.PI)) / (P * 1.5)) * 0.5 + 1),
  smoothStepIn: (t) => 2 * smoothInOut(t / 2),
  smoothStepOut: (t) => 2 * smoothInOut(t / 2 + 0.5) - 1,
  smoothStepInOut: smoothInOut,
  smootherStepIn: (t) => 2 * smootherInOut(t / 2),
  smootherStepOut: (t) => 2 * smootherInOut(t / 2 + 0.5) - 1,
  smootherStepInOut: smootherInOut,
};

/**
 * 譜面イベントの ease / easeDir → イージング関数（SongEvent の `$ease$easeDir`）。
 * "INSTANT" は null（= 即座・duration 無視）、"CLASSIC" は "classic"、不正な名前は linear を返す。
 * ease が quadIn のように方向込みのとき、または linear のときは easeDir を付けない（EASE_TYPE_DIR_REGEX）。
 */
export function easeByName(ease = "linear", dir = "In") {
  ease = String(ease ?? "linear");
  if (ease === "INSTANT") return null;
  if (ease === "CLASSIC") return "classic";
  if (/(In|Out|InOut)$/i.test(ease) || ease === "linear") dir = "";
  return FlxEase[ease + dir] ?? FlxEase.linear;
}

// ---------------------------------------------------------------- 色（Flixel の FlxColor は Int の ARGB）
const NAMED = { BLACK: 0xff000000, WHITE: 0xffffffff, GRAY: 0xff808080, GREEN: 0xff008000, LIME: 0xff00ff00, YELLOW: 0xffffff00, ORANGE: 0xffffa500, RED: 0xffff0000, PURPLE: 0xff800080, BLUE: 0xff0000ff, BROWN: 0xff8b4513, PINK: 0xffffc0cb, MAGENTA: 0xffff00ff, CYAN: 0xff00ffff, TRANSPARENT: 0x00000000 };
const u32 = (n) => n >>> 0;
const rgbOf = (c) => [(c >>> 16) & 255, (c >>> 8) & 255, c & 255];
export const FlxColor = {
  ...NAMED,
  fromString(s) {
    if (s == null) return null;
    s = String(s).trim();
    const u = s.toUpperCase();
    if (NAMED[u] !== undefined) return NAMED[u];
    let m = s.match(/^(?:#|0x)([0-9a-fA-F]{6})$/);
    if (m) return u32(0xff000000 | parseInt(m[1], 16));
    m = s.match(/^(?:#|0x)([0-9a-fA-F]{8})$/);
    if (m) return u32(parseInt(m[1], 16));
    return null;
  },
  fromRGB: (r, g, b, a = 255) => u32((a << 24) | (r << 16) | (g << 8) | b),
  interpolate(c1, c2, f = 0.5) {
    const a = [c1 >>> 24, ...rgbOf(c1)],
      b = [c2 >>> 24, ...rgbOf(c2)];
    const m = a.map((v, i) => Math.round(v + (b[i] - v) * f));
    return u32((m[0] << 24) | (m[1] << 16) | (m[2] << 8) | m[3]);
  },
};

// ---------------------------------------------------------------- 表示物
class Pt {
  constructor(x = 0, y = 0) {
    this.x = x;
    this.y = y;
  }
  set(x, y = x) {
    this.x = x;
    this.y = y;
    return this;
  }
  static get(x = 0, y = 0) {
    return new Pt(x, y);
  }
  static weak(x = 0, y = 0) {
    return new Pt(x, y);
  }
  put() {} // プール返却は何もしない
  clone() {
    return new Pt(this.x, this.y);
  }
  copyFrom(p) {
    this.x = p.x;
    this.y = p.y;
    return this;
  }
  add(x = 0, y = 0) {
    this.x += x;
    this.y += y;
    return this;
  }
  subtract(x = 0, y = 0) {
    this.x -= x;
    this.y -= y;
    return this;
  }
  scale(a, b = a) {
    this.x *= a;
    this.y *= b;
    return this;
  }
  distanceTo(p) {
    return Math.hypot(this.x - p.x, this.y - p.y);
  }
}
class FlxBasic {
  constructor() {
    this.exists = true;
    this.alive = true;
    this.visible = true;
    this.active = true;
    this.cameras = null;
  }
  destroy() {
    this.exists = false;
    this.alive = false;
  }
  kill() {
    this.alive = false;
    this.exists = false;
  }
}
class FlxObject extends FlxBasic {
  constructor(x = 0, y = 0) {
    super();
    this.x = x;
    this.y = y;
    this.alpha = 1;
    this.angle = 0;
    this.scrollFactor = new Pt(1, 1);
    this.scale = new Pt(1, 1);
    this.offset = new Pt(0, 0);
    this.antialiasing = true;
    this.width = 0;
    this.height = 0;
    this.velocity = new Pt(0, 0);
    this.acceleration = new Pt(0, 0);
  }
  /** velocity / acceleration の積分（ランタイムが毎フレーム、表示中の物に呼ぶ） */
  move(dt) {
    const v = this.velocity,
      a = this.acceleration;
    if (!v || !a || (!v.x && !v.y && !a.x && !a.y)) return;
    v.x += a.x * dt;
    v.y += a.y * dt;
    this.x += v.x * dt;
    this.y += v.y * dt;
  }
  screenCenter(axes = "xy") {
    if (axes === "x" || axes === "xy") this.x = (GAME_W - this.width) / 2;
    if (axes === "y" || axes === "xy") this.y = (GAME_H - this.height) / 2;
    return this;
  }
}
export class FlxSprite extends FlxObject {
  constructor(x = 0, y = 0) {
    super(x, y);
    this.color = 0xffffffff;
    this.fw = 0;
    this.fh = 0;
    this.gfx = 0xffffffff; // makeGraphic の色
    this.hb = false; // updateHitbox 済みか
    this.flipX = false;
    this.flipY = false;
  }
  makeGraphic(w, h, color = 0xffffffff) {
    this.fw = w;
    this.fh = h;
    this.gfx = u32(color);
    this.width = w * this.scale.x;
    this.height = h * this.scale.y;
    return this;
  }
  setGraphicSize(w = 0, h = 0) {
    if (w > 0) this.scale.x = w / (this.fw || 1);
    if (h > 0) this.scale.y = h / (this.fh || 1);
    if (w > 0 && h <= 0) this.scale.y = this.scale.x;
    if (h > 0 && w <= 0) this.scale.x = this.scale.y;
    return this;
  }
  updateHitbox() {
    this.width = this.fw * Math.abs(this.scale.x);
    this.height = this.fh * Math.abs(this.scale.y);
    this.hb = true;
  }
  loadGraphic() {
    return this; // 画像の読み込みは未対応（チェーンできるよう自分を返す）
  }
  draw(ctx) {
    if (!this.fw || !this.fh) return;
    const sx = Math.abs(this.scale.x),
      sy = Math.abs(this.scale.y);
    const w = this.fw * sx,
      h = this.fh * sy;
    // updateHitbox 前は、中心を基準に拡大される
    const x = this.hb ? this.x : this.x + (this.fw - w) / 2,
      y = this.hb ? this.y : this.y + (this.fh - h) / 2;
    const [r1, g1, b1] = rgbOf(this.gfx),
      [r2, g2, b2] = rgbOf(this.color);
    const a = (this.gfx >>> 24) / 255;
    ctx.globalAlpha = this.alpha * a;
    ctx.fillStyle = `rgb(${((r1 * r2) / 255) | 0},${((g1 * g2) / 255) | 0},${((b1 * b2) / 255) | 0})`;
    if (this.angle) {
      ctx.save();
      ctx.translate(x + w / 2, y + h / 2);
      ctx.rotate((this.angle * Math.PI) / 180);
      ctx.fillRect(-w / 2, -h / 2, w, h);
      ctx.restore();
    } else ctx.fillRect(x, y, w, h);
  }
}
let measureCtx = null;
export class FlxText extends FlxObject {
  constructor(x = 0, y = 0, fieldWidth = 0, text = "", size = 8) {
    super(x, y);
    this._text = text;
    this.fieldWidth = fieldWidth;
    this.size = size;
    this.color = 0xffffffff;
    this.font = null;
    this.alignment = "left";
    this.borderStyle = "none";
    this.borderColor = 0xff000000;
    this.borderSize = 1;
    this.fontFamily = "system-ui, 'Hiragino Sans', 'Noto Sans JP', sans-serif";
  }
  get text() {
    return this._text;
  }
  set text(v) {
    this._text = String(v ?? "");
  }
  fontStr() {
    return `bold ${this.size}px ${this.fontFamily}`;
  }
  get width() {
    if (this.fieldWidth > 0) return this.fieldWidth;
    if (!measureCtx) measureCtx = document.createElement("canvas").getContext("2d");
    measureCtx.font = this.fontStr();
    return Math.max(...String(this._text).split("\n").map((l) => measureCtx.measureText(l).width), 0) + 4;
  }
  set width(v) {}
  get height() {
    return this.size * 1.25 * String(this._text).split("\n").length + 4;
  }
  set height(v) {}
  setFormat(font, size, color, align, borderStyle, borderColor) {
    if (font) this.font = font;
    if (size) this.size = size;
    if (color != null) this.color = u32(color);
    if (align) this.alignment = align;
    if (borderStyle) this.borderStyle = borderStyle;
    if (borderColor != null) this.borderColor = u32(borderColor);
    return this;
  }
  draw(ctx) {
    if (!this._text) return;
    ctx.globalAlpha = this.alpha;
    ctx.font = this.fontStr();
    ctx.textBaseline = "top";
    const w = this.width,
      lines = String(this._text).split("\n");
    ctx.textAlign = this.alignment === "center" ? "center" : this.alignment === "right" ? "right" : "left";
    const ax = this.alignment === "center" ? this.x + w / 2 : this.alignment === "right" ? this.x + w : this.x;
    const [r, g, b] = rgbOf(this.color);
    lines.forEach((ln, i) => {
      const y = this.y + 2 + i * this.size * 1.25;
      if (this.borderStyle === "outline" || this.borderStyle === "outline_fast") {
        ctx.lineJoin = "round";
        const [br, bg, bb] = rgbOf(this.borderColor);
        ctx.strokeStyle = `rgb(${br},${bg},${bb})`;
        ctx.lineWidth = this.borderSize * 2;
        ctx.strokeText(ln, ax, y);
      } else if (this.borderStyle === "shadow") {
        ctx.fillStyle = "rgba(0,0,0,.6)";
        ctx.fillText(ln, ax + this.borderSize, y + this.borderSize);
      }
      ctx.fillStyle = `rgb(${r},${g},${b})`;
      ctx.fillText(ln, ax, y);
    });
  }
}
export class FlxTypedGroup extends FlxBasic {
  constructor() {
    super();
    this.members = [];
  }
  get length() {
    return this.members.length;
  }
  add(o) {
    if (o && !this.members.includes(o)) this.members.push(o);
    return o;
  }
  insert(i, o) {
    if (o && !this.members.includes(o)) this.members.splice(Math.max(0, Math.min(i, this.members.length)), 0, o);
    return o;
  }
  remove(o) {
    const i = this.members.indexOf(o);
    if (i >= 0) this.members.splice(i, 1);
    return o;
  }
  destroy() {
    for (const m of this.members) m?.destroy?.();
    this.members = [];
    super.destroy();
  }
}

/** funkin.graphics.FunkinTiledSprite（FlxTiledSprite）: 画像を width × height の範囲に敷き詰める。scrollX / scrollY で模様をずらす。描画はステージ（StageScene.drawTiled） */
export class FunkinTiledSprite extends FlxObject {
  constructor(graphic, width = 0, height = 0, repeatX = true, repeatY = true) {
    super(0, 0);
    this.__tiled = true;
    this.path = graphic == null ? "" : String(graphic);
    this.width = Number(width) || 0;
    this.height = Number(height) || 0;
    this.repeatX = repeatX !== false;
    this.repeatY = repeatY !== false;
    this.scrollX = 0;
    this.scrollY = 0;
    this.vcamPoint = null; // 本物は仮想カメラの位置。ここではカメラのスクロールをそのまま使う
    this.zIndex = 0;
    this.img = null;
  }
  setPosition(x = 0, y = 0) {
    this.x = Number(x);
    this.y = Number(y);
    return this;
  }
  loadGraphic(g) {
    this.path = String(g);
    this.img = null;
    return this;
  }
}
/** funkin.graphics.FunkinBackdrop（FlxBackdrop）: 画像を指定の軸に無限に敷く。axes: X=0x01 / Y=0x10 / XY=0x11。tint(color) / blend は未対応 */
export class FunkinBackdrop extends FunkinTiledSprite {
  constructor(graphic, axes = 0x11) {
    super(graphic, 0, 0, true, true);
    this.__backdrop = true;
    const a = typeof axes === "string" ? ({ x: 1, y: 16, xy: 17 }[axes.toLowerCase()] ?? 17) : Number(axes);
    this.repeatX = !!(a & 1);
    this.repeatY = !!(a & 16);
    this.width = 1;
    this.height = 1;
    this.color = 0xffffffff;
    this.blend = 0;
  }
}
/** openfl.filters.BlurFilter（スクリプトで new するだけで、いまは描画に使わない） */
export class BlurFilter {
  constructor(blurX = 4, blurY = 4, quality = 1) {
    Object.assign(this, { blurX, blurY, quality });
  }
}

export class FlxCamera {
  constructor(name) {
    this.name = name;
    this.filters = [];
    this.alpha = 1;
    this.zoom = 1;
    this.width = GAME_W;
    this.height = GAME_H;
    this.layer = null; // フィルター用のオフスクリーン
    this.shakeFx = null;
  }
  /** FlxCamera.shake(intensity, duration, onComplete, force, axes)。intensity = 画面の幅（高さ）に対する割合 */
  shake(intensity = 0.05, duration = 0.5, onComplete = null, force = true) {
    if (!force && this.shakeFx) return;
    this.shakeFx = { intensity: Number(intensity), duration: Math.max(0.001, Number(duration)), t0: performance.now(), onComplete };
  }
  /** FlxCamera.fade(color, duration, fadeIn, onComplete, force)。fadeIn=true は「色 → 透明」 */
  fade(color = 0xff000000, duration = 1, fadeIn = false, onComplete = null, force = false) {
    if (!force && this.fadeFx) return;
    this.fadeFx = { color, duration: Math.max(0.001, Number(duration)), fadeIn: !!fadeIn, t0: performance.now(), onComplete };
  }
  /** FlxCamera.flash(color, duration, onComplete, force)。色から透明へ */
  flash(color = 0xffffffff, duration = 1, onComplete = null, force = false) {
    if (!force && this.flashFx) return;
    this.flashFx = { color, duration: Math.max(0.001, Number(duration)), t0: performance.now(), onComplete };
  }
  stopFX() {
    this.fadeFx = this.flashFx = this.shakeFx = null;
  }
  /** フェード / フラッシュの重ね色（CSS の色と alpha の配列）。無ければ null */
  overlays() {
    const out = [];
    const css = (c) => {
      const n = Number(c) >>> 0;
      return [`rgb(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255})`, (n >>> 24) / 255 || 1];
    };
    for (const key of ["fadeFx", "flashFx"]) {
      const f = this[key];
      if (!f) continue;
      const t = (performance.now() - f.t0) / 1000 / f.duration;
      if (t >= 1 && !f.done) {
        f.done = true;
        try {
          f.onComplete?.();
        } catch {}
      }
      const u = Math.min(1, t);
      const toClear = key === "flashFx" || f.fadeIn; // 色 → 透明（終わったら消える）。フェードアウトは終わっても色が残る
      if (t >= 1 && toClear) {
        if (this[key] === f) this[key] = null;
        continue;
      }
      const [col, a0] = css(f.color);
      out.push([col, (toClear ? 1 - u : u) * a0]);
    }
    return out;
  }
  /** いまの揺れ（画面 px）。終わったら onComplete を呼んで null */
  shakeOffset(W, H) {
    const s = this.shakeFx;
    if (!s) return null;
    const el = (performance.now() - s.t0) / 1000;
    if (el >= s.duration) {
      this.shakeFx = null;
      try {
        s.onComplete?.();
      } catch {}
      return null;
    }
    return [(Math.random() * 2 - 1) * s.intensity * W, (Math.random() * 2 - 1) * s.intensity * H];
  }
}
export class FlxCamFilter {
  // ShaderFilter(shader)
  constructor(shader) {
    this.shader = shader;
  }
}
/** Grayscale シェーダー（amount 0 = 元の色、1 = 白黒） */
export class Grayscale {
  constructor(amount = 0) {
    this.amount = amount;
    this.glsl = GLSL_GRAYSCALE;
  }
  get uniforms() {
    return { amount: this.amount };
  }
  setAmount(a) {
    this.amount = a;
  }
  active() {
    return this.amount > 0.0005;
  }
}

// ---------------------------------------------------------------- Tween
class Tween {
  constructor(mgr, o) {
    Object.assign(this, { mgr, active: true, finished: false, elapsed: 0, value: 0, delay: o.delay || 0 });
    this.duration = Math.max(0.0001, o.duration);
    this.ease = o.ease || FlxEase.linear;
    this.onUpdate = o.onUpdate;
    this.onComplete = o.onComplete;
    this.setup = o.setup; // elapsed 比率 → 値を反映
    this.loop = o.loop;
  }
  cancel() {
    this.finished = true;
    this.active = false;
    this.mgr.remove(this);
  }
  destroy() {
    this.cancel();
  }
  step(dt) {
    if (this.delay > 0) {
      this.delay -= dt;
      if (this.delay > 0) return;
      dt = -this.delay;
      this.delay = 0;
    }
    this.elapsed += dt;
    const t = Math.min(1, this.elapsed / this.duration);
    this.setup(this.ease(t), this);
    this.onUpdate?.(this);
    if (t >= 1) {
      if (this.loop) {
        this.elapsed = 0;
        return;
      }
      this.finished = true;
      this.mgr.remove(this);
      this.onComplete?.(this);
    }
  }
}
class TweenManager {
  constructor() {
    this.list = [];
  }
  remove(t) {
    const i = this.list.indexOf(t);
    if (i >= 0) this.list.splice(i, 1);
  }
  clear() {
    this.list = [];
  }
  update(dt) {
    for (const t of this.list.slice()) if (t.active && !t.finished) t.step(dt);
  }
}

// ---------------------------------------------------------------- ランタイム本体
const withStubs = (obj, path, stub) =>
  new Proxy(obj, {
    get(t, p) {
      if (typeof p === "symbol" || p in t) return Reflect.get(t, p);
      if (String(p).startsWith("__") || p === "then" || p === "toJSON") return undefined; // インタプリタの内部探索に反応しない
      return stub(`${path}.${String(p)}`);
    },
    set(t, p, v) {
      t[p] = v;
      return true;
    },
  });

export class Runtime {
  /**
   * @param opts { noteStyles: NoteStyleSet, getOpts(): {down, ...}, onLog(msg) }
   */
  constructor(opts = {}) {
    this.opts = opts;
    this.gl = null; // 必要になったときだけ作る
    this.scripts = new Map(); // ファイル名 → テキスト
    this.reset();
  }
  /** 全部作り直す（プレイテストを始めるたびに呼ぶ。スクリプトの内部状態も新品になる） */
  reset() {
    this.warnings = new Set(); // 未対応 API
    this.errors = []; // スクリプトの実行エラー
    this.tweens = new TweenManager();
    this.postUpdate = [];
    this.timers = new Set();
    this.atlases = new Map();
    this.sounds = new Set();
    this.pos = 0;
    this.modules = new Map();
    this.stages = []; // いまのステージ用のステージスクリプト（extends Stage）のインスタンス
    this.eventInst = new Map(); // kind → {inst, processOld}
    this.noteKinds = new Map(); // kind 名 → NoteKind のインスタンス（スクリプト）/ 組み込み
    this.liveNotes = []; // いま画面にあるノート（NoteSprite の代役）。getNotes() が返す
    // 組み込みの kind（V-Slice の NoAnimNoteKind / NonScoreableNoteKind）
    this.noteKinds.set("noanim", { noteKind: "noanim", noanim: true, suffix: "", scoreable: true, noteStyleId: null, params: [] });
    this.noteKinds.set("non_scoreable", {
      noteKind: "non_scoreable", noanim: false, suffix: "", scoreable: false, noteStyleId: null, params: [],
      native: { onNoteMiss: (ev) => { ev.note.visible = false; ev.cancel(); } },
    });
    this.cams = { camGame: new FlxCamera("camGame"), camHUD: new FlxCamera("camHUD"), camCutscene: new FlxCamera("camCutscene") };
    this.ps = null;
    this.hs = null;
    this.logs = [];
    this.loaded = [];
    this.build();
  }
  warn(msg) {
    if (!this.warnings.has(msg)) {
      this.warnings.add(msg);
    }
  }
  fail(where, e) {
    const msg = `${where}: ${e instanceof Error ? e.message : String(e)}`;
    if (!this.errors.includes(msg)) this.errors.push(msg);
  }
  stub(path) {
    if (!this._stubs) this._stubs = new Map();
    if (!this._stubs.has(path)) this._stubs.set(path, makeStub(path, (p, isSet) => this.warn(isSet ? `${p}（代入）` : `${p}()`)));
    return this._stubs.get(path);
  }

  build() {
    const rt = this;
    const stub = (p) => rt.stub(p);
    const ns = this.opts.noteStyles;
    const arrows = () => Array.from({ length: 4 }, (_, i) => withStubs({ direction: i, x: 0, y: 0, scale: new Pt(1, 1), updateHitbox() {}, playStatic() {}, playPress() {}, playConfirm() {} }, "StrumlineNote", stub));
    const strumline = (name) =>
      withStubs({ noteStyle: null, notes: { members: [] }, holdNotes: { members: [] }, strumlineNotes: { members: arrows() }, strumlineScale: new Pt(1, 1) }, name, stub);
    const ps = {
      camGame: this.cams.camGame,
      camHUD: this.cams.camHUD,
      camCutscene: this.cams.camCutscene,
      members: [],
      isMinimalMode: false,
      playerStrumline: strumline("PlayState.playerStrumline"),
      opponentStrumline: strumline("PlayState.opponentStrumline"),
      currentSong: { id: this.opts.songId ?? "", songName: this.opts.songId ?? "" },
      currentChart: { scrollSpeed: 1, characters: this.opts.characters ?? { player: "bf", girlfriend: "gf", opponent: "dad" } },
      add(o) {
        if (o && !this.members.includes(o)) this.members.push(o);
        return o;
      },
      insert(i, o) {
        if (o && !this.members.includes(o)) this.members.splice(Math.max(0, Math.min(i, this.members.length)), 0, o);
        return o;
      },
      remove(o) {
        const i = this.members.indexOf(o);
        if (i >= 0) this.members.splice(i, 1);
        return o;
      },
    };
    this.ps = withStubs(ps, "PlayState", stub);
    const psRef = this.ps;
    const baseGroup = FlxTypedGroup;
    const G = {
      // ---- ゲームの基本
      PlayState: { instance: psRef },
      FlxG: withStubs(
        {
          width: GAME_W,
          height: GAME_H,
          console: { registerObject() {}, registerFunction() {} },
          elapsed: 1 / 60,
          signals: { postUpdate: { add: (f) => rt.postUpdate.push(f), remove: (f) => (rt.postUpdate = rt.postUpdate.filter((x) => x !== f)) }, preUpdate: { add() {}, remove() {} } },
          random: {
            int: (a = 0, b = 1) => a + Math.floor(Math.random() * (b - a + 1)),
            float: (a = 0, b = 1) => a + Math.random() * (b - a),
            bool: (chance = 50) => Math.random() * 100 < chance,
            sign: (chance = 50) => (Math.random() * 100 < chance ? 1 : -1),
          },
          camera: this.cams.camGame,
          cameras: { list: Object.values(this.cams) },
          sound: { list: { add: (x) => x, remove: (x) => x }, music: null, muted: false, volume: 1 },
        },
        "FlxG",
        stub,
      ),
      Conductor: {
        instance: withStubs(
          {
            get songPosition() {
              return rt.pos;
            },
            get bpm() {
              const t = rt.scene?.o?.timing?.();
              return t ? 60000 / (t.stepToMs(4) - t.stepToMs(0) || 600) : 100;
            },
            get beatLengthMs() {
              const t = rt.scene?.o?.timing?.();
              return t ? t.stepToMs(rt.lastStep + 4 || 4) - t.stepToMs(rt.lastStep || 0) : 600;
            },
            get stepLengthMs() {
              return this.beatLengthMs / 4;
            },
            get currentStep() {
              return rt.lastStep ?? 0;
            },
            get currentBeat() {
              return Math.floor((rt.lastStep ?? 0) / 4);
            },
          },
          "Conductor.instance",
          stub,
        ),
      },
      Preferences: withStubs(
        {
          flashingLights: true,
          get downscroll() {
            return !!rt.opts.getOpts?.().down;
          },
          get_downscroll: () => !!rt.opts.getOpts?.().down,
        },
        "Preferences",
        stub,
      ),
      Save: { instance: withStubs({ modOptions: { get: () => null, set() {} } }, "Save.instance", stub) },
      ModuleHandler: { getModule: (id) => rt.modules.get(id) ?? null },
      Paths: withStubs(
        {
          font: (f) => f,
          image: (p) => String(p),
          frag: (p) => String(p), // .frag の中身は Assets.getText が名前で探す
          sound: (p) => String(p), // 実際の読み込みは FunkinSound.load が行う
          music: (p) => String(p),
          getSparrowAtlas: (p) => rt.loadAtlas(String(p)),
        },
        "Paths",
        stub,
      ),
      FunkinSound: withStubs(
        {
          load: (p, volume = 1, looped = false, _autoDestroy = false, autoPlay = false) => rt.makeSound(String(p), volume, looped, autoPlay),
          playOnce: (p, volume = 1) => rt.makeSound(String(p), volume, false, true),
        },
        "FunkinSound",
        stub,
      ),
      // 端末の振動。プレイテスト（PC）では何もしない
      HapticUtil: withStubs({ vibrate() {}, vibrateByPattern() {}, stop() {} }, "HapticUtil", stub),
      FlxTimer: class {
        constructor() {
          this.active = false;
          this.finished = false;
          this.elapsedLoops = 0;
          this.time = 0;
          this.loops = 1;
          this.t = 0;
        }
        start(time = 1, cb = null, loops = 1) {
          Object.assign(this, { time: Number(time), cb, loops: Number(loops), t: 0, elapsedLoops: 0, active: true, finished: false });
          rt.timers.add(this);
          return this;
        }
        cancel() {
          this.active = false;
          rt.timers.delete(this);
        }
        get loopsLeft() {
          return this.loops - this.elapsedLoops;
        }
        get timeLeft() {
          return this.time - this.t;
        }
        step(dt) {
          if (!this.active) return;
          this.t += dt;
          while (this.active && this.t >= this.time) {
            this.t -= this.time;
            this.elapsedLoops++;
            try {
              this.cb?.(this);
            } catch (e) {
              rt.fail("FlxTimer", e);
            }
            if (this.loops > 0 && this.elapsedLoops >= this.loops) {
              this.active = false;
              this.finished = true;
              rt.timers.delete(this);
            }
            if (this.time <= 0) break;
          }
        }
      },
      Assets: {
        cacheSound: () => {},
        cacheFlxGraphic: () => {},
        exists: (p) => rt.fragText(p) != null,
        getText: (p) => rt.fragText(p) ?? "",
      },
      FlxRuntimeShader,
      CharacterType: { BF: "BF", DAD: "DAD", GF: "GF", OTHER: "OTHER" },
      FunkinTiledSprite,
      FunkinBackdrop,
      FlxBackdrop: FunkinBackdrop,
      FlxTiledSprite: FunkinTiledSprite,
      BlurFilter,
      FlxAngle: { asRadians: (d) => (Number(d) * Math.PI) / 180, asDegrees: (r) => (Number(r) * 180) / Math.PI, TO_RAD: Math.PI / 180, TO_DEG: 180 / Math.PI },
      // funkin.util.MathUtil（実ソース MathUtil.hx と同じ式）
      MathUtil: {
        lerp: (a, b, t) => a + (b - a) * t,
        smoothLerpPrecision: (base, target, dt, duration, precision = 0.01) => (dt === 0 ? base : base === target ? target : target + (base - target) * Math.pow(precision, dt / duration)),
        smoothLerpDecay: (base, target, dt, halfLife) => (dt === 0 ? base : base === target ? target : target + (base - target) * Math.pow(2, -dt / halfLife)),
        snap: (base, target, th) => (Math.abs(base - target) <= th ? target : base),
      },
      ...Object.fromEntries(
        NATIVE_SHADERS.map((sp) => {
          const C = makeNativeShader((k) => rt.fragText(k), sp);
          for (const k of Object.keys(shaderMethods)) C.prototype[k] ??= shaderMethods[k];
          return [sp.name, C];
        }),
      ),
      MosaicEffect: (() => {
        const C = makeMosaicEffect((k) => rt.fragText(k), Pt);
        for (const k of Object.keys(shaderMethods)) C.prototype[k] ??= shaderMethods[k];
        return C;
      })(),
      RuntimeRainShader: (() => {
        const C = makeRainShader((k) => rt.fragText(k));
        for (const k of ["setFloat", "setFloatArray", "setInt", "setIntArray", "setBool", "setBoolArray", "setSampler2D", "getFloat", "getFloatArray", "getInt", "getBool", "active"]) C.prototype[k] = shaderMethods[k];
        return C;
      })(),
      AdjustColorShader: (() => {
        const C = makeAdjustColorShader((k) => rt.fragText(k));
        Object.assign(C.prototype, shaderMethods);
        return C;
      })(),
      // ---- 表示物
      FlxSprite,
      FlxText,
      FlxTypedGroup: baseGroup,
      FlxGroup: baseGroup,
      FlxSpriteGroup: baseGroup,
      FlxColor,
      FlxEase,
      FlxTextAlign: { LEFT: "left", CENTER: "center", RIGHT: "right", JUSTIFY: "left" },
      FlxTextBorderStyle: { NONE: "none", SHADOW: "shadow", OUTLINE: "outline", OUTLINE_FAST: "outline_fast" },
      FlxAxes: { X: "x", Y: "y", XY: "xy" },
      FlxPoint: Pt,
      ShaderFilter: FlxCamFilter,
      FlxTween: {
        tween(obj, props, duration, o = {}) {
          const from = {};
          for (const k of Object.keys(props)) from[k] = obj[k];
          const tw = new Tween(rt.tweens, {
            duration,
            ease: o.ease,
            delay: o.startDelay,
            onUpdate: o.onUpdate,
            onComplete: o.onComplete,
            loop: o.type === 2 || o.type === "looping",
            setup: (e) => {
              for (const k of Object.keys(props)) obj[k] = from[k] + (props[k] - from[k]) * e;
            },
          });
          tw.target = obj;
          rt.tweens.list.push(tw);
          return tw;
        },
        /** angle(obj, from, to, duration, options): 回転角を from → to へ（NaN のときは今の角度から） */
        angle(obj, from, to, duration, o) {
          o ??= {};
          const a0 = Number.isFinite(Number(from)) ? Number(from) : obj.angle || 0;
          const tw = new Tween(rt.tweens, {
            duration,
            ease: o.ease,
            delay: o.startDelay,
            onUpdate: o.onUpdate,
            onComplete: o.onComplete,
            setup: (e) => (obj.angle = a0 + (Number(to) - a0) * e),
          });
          tw.target = obj;
          rt.tweens.list.push(tw);
          return tw;
        },
        /** linearPath / quadPath(obj, points, durationOrSpeed, useDuration, options): 点列に沿って x / y を動かす（quad は 始点, 制御点, 終点, 制御点, 終点… の二次ベジエ） */
        linearPath(obj, points, d, useDuration = true, o) {
          return this.quadPath(obj, points, d, useDuration, o, true);
        },
        quadPath(obj, points, d, useDuration = true, o, linear = false) {
          o ??= {};
          const P = (points || []).map((p) => [Number(p.x), Number(p.y)]);
          if (P.length < 2) return null;
          // 折れ線 / 曲線を細かく刻み、距離で進行度を決める
          const pts = [P[0]];
          if (linear) pts.push(...P.slice(1));
          else
            for (let i = 0; i + 2 < P.length + (P.length % 2 ? 0 : 1); i += 2) {
              const a = P[i],
                c = P[i + 1],
                b = P[i + 2] ?? P[i + 1];
              for (let k = 1; k <= 24; k++) {
                const t = k / 24,
                  u = 1 - t;
                pts.push([u * u * a[0] + 2 * u * t * c[0] + t * t * b[0], u * u * a[1] + 2 * u * t * c[1] + t * t * b[1]]);
              }
            }
          const acc = [0];
          for (let i = 1; i < pts.length; i++) acc.push(acc[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]));
          const total = acc[acc.length - 1] || 1;
          const duration = useDuration ? Number(d) : total / Math.max(1e-6, Number(d));
          const tw = new Tween(rt.tweens, {
            duration,
            ease: o.ease,
            delay: o.startDelay,
            onUpdate: o.onUpdate,
            onComplete: o.onComplete,
            setup: (e) => {
              const dist = total * Math.min(1, Math.max(0, e));
              let i = 1;
              while (i < acc.length - 1 && acc[i] < dist) i++;
              const span = acc[i] - acc[i - 1] || 1,
                f = (dist - acc[i - 1]) / span;
              obj.x = pts[i - 1][0] + (pts[i][0] - pts[i - 1][0]) * f;
              obj.y = pts[i - 1][1] + (pts[i][1] - pts[i - 1][1]) * f;
            },
          });
          tw.target = obj;
          rt.tweens.list.push(tw);
          return tw;
        },
        cancelTweensOf(obj, fields) {
          const l = rt.tweens.list;
          for (let i = l.length - 1; i >= 0; i--) if (l[i].target === obj) l.splice(i, 1);
        },
        num(a, b, duration, o = {}, fn) {
          const tw = new Tween(rt.tweens, {
            duration,
            ease: o.ease,
            delay: o.startDelay,
            onUpdate: (t) => {
              o.onUpdate?.(t);
              fn?.(t.value);
            },
            onComplete: o.onComplete,
            setup: (e, t) => (t.value = a + (b - a) * e),
          });
          tw.value = a;
          rt.tweens.list.push(tw);
          return tw;
        },
      },
      // ---- ノートスキン
      NoteStyleRegistry: {
        instance: {
          fetchEntry: (id) => (ns?.get(id) ? rt.styleApi(ns.get(id)) : null),
          fetchDefault: () => (ns?.get("funkin") ? rt.styleApi(ns.get("funkin")) : null),
          listEntryIds: () => ns?.ids() ?? [],
        },
      },
      FunkinMemory: withStubs({ cacheNoteStyle() {} }, "FunkinMemory", stub),
      // ---- スクリプトの土台
      SongEventSchema: class {
        constructor(fields) {
          this.fields = fields;
        }
      },
      SongEventFieldType: { STRING: "string", INTEGER: "integer", FLOAT: "float", BOOL: "bool", ENUM: "enum", FRAME: "frame" },
      // ---- Haxe 標準
      Std: {
        int: (x) => Math.trunc(x),
        string: (x) => (x == null ? "null" : String(x)),
        parseInt: (s) => {
          const n = parseInt(s);
          return Number.isNaN(n) ? null : n;
        },
        parseFloat: (s) => parseFloat(s),
        isOfType: (v, T) => (T === G.Int ? Number.isInteger(v) : T === G.Float ? typeof v === "number" : T === G.String ? typeof v === "string" : T === G.Bool ? typeof v === "boolean" : T === G.Array ? Array.isArray(v) : v != null),
        random: (n) => Math.floor(Math.random() * n),
      },
      Int: { __t: "Int" },
      Float: { __t: "Float" },
      String: { __t: "String", fromCharCode: (c) => String.fromCharCode(c) },
      Bool: { __t: "Bool" },
      Array: { __t: "Array" },
      Dynamic: { __t: "Dynamic" },
      Math: Object.assign(Object.create(Math), { isNaN: Number.isNaN, isFinite: Number.isFinite, NaN: NaN, POSITIVE_INFINITY: Infinity, NEGATIVE_INFINITY: -Infinity }),
      Reflect: {
        field: (o, n) => (o == null ? null : o[n] === undefined ? null : o[n]),
        setField: (o, n, v) => void (o[n] = v),
        hasField: (o, n) => o != null && n in o,
        fields: (o) => Object.keys(o),
        callMethod: (o, f, a) => f.apply(o, a),
      },
      StringMap: HMap,
      IntMap: HMap,
      ObjectMap: HMap,
      StringTools: { trim: (s) => s.trim(), startsWith: (s, p) => s.startsWith(p), endsWith: (s, p) => s.endsWith(p), replace: (s, a, b) => s.split(a).join(b) },
      trace: (...a) => rt.log(a.join(" ")),
    };
    this.G = G;
    // スクリプトの基底クラス
    const noop = () => null;
    const bases = {
      SongEvent: {
        init(inst, args) {
          inst.__eventId = args[0];
          inst.__opts = args[1] ?? {};
          rt.eventInst.set(args[0], { inst, processOld: !!inst.__opts.processOldEvents });
        },
        methods: {
          getTitle() {
            return this.__eventId;
          },
          getEventSchema: noop,
          handleEvent: noop,
        },
      },
      NoteKind: {
        init(inst, args) {
          inst.noteKind = args[0] == null ? "UNKNOWN" : String(args[0]);
          inst.description = args[1] ?? "";
          inst.noteStyleId = args[2] ?? null;
          inst.params = args[3] ?? [];
          inst.noanim = !!args[4];
          inst.suffix = args[5] ?? "";
          inst.scoreable = true;
          rt.noteKinds.set(inst.noteKind, inst);
        },
        methods: {
          toString() {
            return this.noteKind;
          },
          getNotes: (visible) => rt.liveNotes.filter((n) => n.noteData.kind === undefined || true).filter((n) => !visible || n.visible),
          getOtherNotes: (visible) => rt.liveNotes.filter((n) => !visible || n.visible),
          onScriptEvent: noop, onCreate: noop, onDestroy: noop, onUpdate: noop,
          onNoteIncoming: noop, onNoteHit: noop, onNoteMiss: noop, onNoteHoldDrop: noop,
        },
      },
      Module: {
        init(inst, args) {
          inst.__moduleId = args[0];
          rt.modules.set(args[0], inst);
        },
        methods: {
          scriptCall(name, args = []) {
            return rt.hs.has(this, name) ? rt.hs.call(this, name, args) : null;
          },
          scriptGet: (n) => null,
        },
      },
    };
    // ステージスクリプト（class X extends Stage { function new() { super('stageId'); } }）。いま読み込んでいるステージの id と同じものだけ動かす
    const stageNoop = () => null;
    bases.Stage = {
      init(inst, args) {
        inst.stageId = String(args[0] ?? "");
        inst.stageName = inst.stageId;
        inst.characters = { remove() {}, set() {}, get: () => null, exists: () => false, keys: () => [] }; // Stage.characters（id → キャラ）
        if (rt.scene && rt.scene.stageId.toLowerCase() === inst.stageId.toLowerCase()) rt.stages.push(inst);
      },
      methods: {
        buildStage: stageNoop, // 本物は JSON から props を作る処理。こちらではシーンが先に作ってあるので何もしない
        fetchAssetPaths: () => [],
        getNamedProp(name) {
          return rt.scene?.propApi(String(name)) ?? null;
        },
        getBoyfriend: () => rt.ps.getBoyfriend?.() ?? null,
        getDad: () => rt.ps.getDad?.() ?? null,
        getGirlfriend: () => rt.ps.getGirlfriend?.() ?? null,
        add: (o) => rt.ps.currentStage?.add?.(o),
        remove: (o) => rt.ps.currentStage?.remove?.(o),
        insert: (i, o) => rt.ps.currentStage?.insert?.(i, o),
        refresh: stageNoop,
        addCharacter: (c) => c, // 本物は stage.add(character)。シーンが先にキャラを置いてあるので何もしない
        onScriptEvent: stageNoop, onCreate: stageNoop, onDestroy: stageNoop, onUpdate: stageNoop,
        onBeatHit: stageNoop, onStepHit: stageNoop, onSongStart: stageNoop, onSongEnd: stageNoop, onSongRetry: stageNoop,
        onCountdownStart: stageNoop, onCountdownStep: stageNoop, onCountdownEnd: stageNoop, onPause: stageNoop, onResume: stageNoop,
        onNoteIncoming: stageNoop, onNoteHit: stageNoop, onNoteMiss: stageNoop, onNoteHoldDrop: stageNoop,
        onGameOver: stageNoop, onSongLoaded: stageNoop, onSongEvent: stageNoop,
      },
    };
    // script class の extends FlxRuntimeShader（BuildingEffectShader など）
    bases.FlxRuntimeShader = { init: (inst, args) => shaderInit(inst, args[0]), methods: shaderMethods };
    bases.ScriptedStage = bases.Stage;
    bases.ScriptedSongEvent = bases.SongEvent;
    bases.ScriptedModule = bases.Module;
    bases.ScriptedNoteKind = bases.NoteKind;
    // getNotes / getOtherNotes は自分の kind で絞る
    bases.NoteKind.methods.getNotes = function (v) { return rt.liveNotes.filter((n) => n.noteData.kind === this.noteKind && (!v || n.visible)); };
    bases.NoteKind.methods.getOtherNotes = function (v) { return rt.liveNotes.filter((n) => n.noteData.kind !== this.noteKind && (!v || n.visible)); };
    this.hs = new HScript({ globals: G, bases, onStub: (p, isSet) => this.warn(isSet ? `${p}（代入）` : `${p}()`) });
  }
  /** Assets.getText(Paths.frag('名前')): 名前（フォルダ・拡張子・大文字小文字・- _ のちがいは無視）で .frag のテキストを返す */
  fragText(p) {
    const k = String(p ?? "").replace(/^.*[\\/]/, "").replace(/\.frag$/i, "").toLowerCase().replace(/[-_ ]/g, "");
    return this.frags?.[k] ?? null;
  }
  /** .frag のテキストを登録（キーは名前をそろえたもの）。mod のもの・本体（funkin.assets）のもの */
  setFrags(map) {
    this.frags = { ...(this.frags ?? {}), ...map };
  }
  log(msg) {
    this.logs.push(msg);
    if (this.logs.length > 200) this.logs.shift();
    this.opts.onLog?.(msg);
  }

  // ---------------------------------------------------------------- スクリプト
  /** テキストを読み込み、中の SongEvent / Module を作る。 → {events:[kind], modules:[id]} */
  loadScript(text, name) {
    const before = { e: new Set(this.eventInst.keys()), m: new Set(this.modules.keys()) };
    try {
      const defs = this.hs.load(text, name);
      for (const c of defs) {
        const root = this.hs.rootBase(c);
        if (root === "SongEvent" || root === "ScriptedSongEvent" || root === "Stage" || root === "ScriptedStage" || root === "Module" || root === "ScriptedModule" || root === "NoteKind" || root === "ScriptedNoteKind") {
          try {
            this.hs.instantiate(c);
          } catch (e) {
            this.fail(`${name}: ${c.name} を作れません`, e);
          }
        }
      }
    } catch (e) {
      this.fail(`${name}: 読み込めません`, e);
    }
    return { events: [...this.eventInst.keys()].filter((k) => !before.e.has(k)), modules: [...this.modules.keys()].filter((k) => !before.m.has(k)) };
  }
  /** ステージとキャラ（StageScene）を PlayState の代役につなぐ: getBoyfriend / getDad / getGirlfriend / currentStage など */
  attachScene(scene) {
    this.scene = scene;
    const ps = this.ps,
      stub = (p) => this.stub(p);
    const wrap = new Map();
    const w = (key, make, path) => (wrap.has(key) ? wrap.get(key) : (wrap.set(key, withStubs(make(), path, stub)), wrap.get(key)));
    ps.currentStage = w("stage", () => scene.stageApi(), "PlayState.currentStage");
    ps.currentStageId = scene.stageId;
    const who = { getBoyfriend: "player", getDad: "opponent", getGirlfriend: "girlfriend" };
    for (const [fn, role] of Object.entries(who)) ps[fn] = () => w(role, () => scene.apiOf(role), "Character");
    // stage.add(x): キャラならシーンへ、それ以外（FlxSprite など）は PlayState の members へ
    const sApi = scene.stageApi();
    for (const m of ["add", "remove", "insert"]) {
      const orig = sApi[m];
      ps.currentStage[m] = (...a) => {
        const o = a[a.length - 1];
        if (o?.__char || o?.__tiled) return orig(...a);
        return ps[m]?.(...a);
      };
    }
    this.G.PlayState.currentStage = ps.currentStage;
    this.G.PlayState.getBoyfriend = ps.getBoyfriend;
    this.G.PlayState.getDad = ps.getDad;
    this.G.PlayState.getGirlfriend = ps.getGirlfriend;
    this.G.CharacterDataParser = withStubs(
      {
        fetchCharacter: (id) => scene.fetchCharacter(String(id)),
        fetchCharacterData: (id) => (scene.charFiles.has(String(id)) ? { id: String(id) } : null),
        listCharacterIds: () => [...scene.charFiles.keys()],
      },
      "CharacterDataParser",
      (p) => this.stub(p),
    );
    // CharacterRegistry.instance.fetchEntry(id)（0.9 の新しいキャラ取得）は、fetchCharacter と同じ
    this.G.CharacterRegistry = { instance: withStubs({ fetchEntry: (id) => scene.fetchCharacter(String(id)), hasEntry: (id) => scene.charFiles.has(String(id)), listEntryIds: () => [...scene.charFiles.keys()] }, "CharacterRegistry", (p) => this.stub(p)) };
    // FlxTypedSpriteGroup: キャラを入れる入れ物。入れたキャラはステージに出し、グループの zIndex を使う（kill / revive はまとめて）
    this.G.FlxTypedSpriteGroup = this.G.FlxSpriteGroup = class {
      constructor() {
        this.members = [];
        this.zIndex = 0;
        this.exists = true;
        this.alive = true;
        this.visible = true;
        this.alpha = 1;
      }
      get length() {
        return this.members.length;
      }
      add(o) {
        if (o && !this.members.includes(o)) this.members.push(o);
        if (o?.__char) {
          o.__char.zIndex = this.zIndex;
          scene.addExtra(o.__char);
        }
        return o;
      }
      remove(o) {
        this.members = this.members.filter((x) => x !== o);
        if (o?.__char) scene.removeExtra(o.__char);
        return o;
      }
      forEach(fn) {
        for (const m of [...this.members]) fn(m);
      }
      kill() {
        this.alive = false;
        for (const m of this.members) m?.kill?.();
      }
      revive() {
        this.alive = true;
      }
      destroy() {
        this.kill();
        this.members = [];
      }
    };
    ps.currentStage.getBoyfriend = ps.getBoyfriend;
    ps.currentStage.getDad = ps.getDad;
    ps.currentStage.getGirlfriend = ps.getGirlfriend;
    Object.defineProperty(ps, "currentCameraZoom", { get: () => scene.zoom, set: (v) => (scene.zoom = Number(v)), configurable: true });
    Object.defineProperty(ps, "defaultCameraZoom", { get: () => scene.zoomBase, set: (v) => (scene.zoomBase = Number(v)), configurable: true });
    ps.cameraFollowPoint = { get x() { return scene.focusTarget.x; }, set x(v) { scene.focusTarget.x = Number(v); }, get y() { return scene.focusTarget.y; }, set y(v) { scene.focusTarget.y = Number(v); }, setPosition(x, y) { scene.focusTarget = { x: Number(x), y: Number(y) }; } };
  }
  /** Paths.getSparrowAtlas(path): すぐ返し、絵と XML は裏で読む（ready になるまで描かれない） */
  loadAtlas(path) {
    const key = path.replace(/^[^:]*:/, "").replace(/\.(png|xml)$/i, "");
    if (this.atlases.has(key)) return this.atlases.get(key);
    const at = { path: key, ready: false, failed: false, img: null, sprites: null, __atlas: true };
    this.atlases.set(key, at);
    const res = this.scene?.o.resolve,
      origin = this.scene?.o.origin;
    const png = res?.("image", key, { origin, quiet: true }),
      xml = res?.("xml", key, { origin, quiet: true });
    if (!png || !xml) {
      at.failed = true;
      this.warn(`Paths.getSparrowAtlas("${path}"): 読み込んだ mod に ${!png ? "画像(PNG)" : "XML"} が見つかりません`);
      return at;
    }
    (async () => {
      try {
        at.img = await loadImage(png);
        at.sprites = parseSparrowXml((await xml.text()).replace(/^\uFEFF/, ""));
        at.ready = true;
      } catch (e) {
        at.failed = true;
        this.warn(`Paths.getSparrowAtlas("${path}"): 読み込みに失敗しました（${e.message}）`);
      }
    })();
    return at;
  }
  /** FunkinSound.load(path, volume, looped, autoDestroy, autoPlay) の代役（WebAudio。mod の sounds/ から探す） */
  makeSound(path, volume = 1, looped = false, autoPlay = false) {
    const rt = this;
    const s = {
      volume: Number(volume),
      looped: !!looped,
      playing: false,
      _want: false,
      _buf: null,
      _src: null,
      onComplete: null,
      play(forceRestart = false) {
        if (this.playing && !forceRestart) return this;
        this._want = true;
        this._start();
        return this;
      },
      _start() {
        if (!this._buf || !this._want) return;
        try {
          this._src?.stop();
        } catch {}
        const ctx = (rt.actx ??= new (window.AudioContext || window.webkitAudioContext)());
        const src = ctx.createBufferSource(),
          gain = ctx.createGain();
        src.buffer = this._buf;
        src.loop = this.looped;
        gain.gain.value = this.volume;
        src.connect(gain).connect(ctx.destination);
        src.onended = () => {
          if (this._src === src) {
            this.playing = false;
            this._want = false;
            try {
              this.onComplete?.();
            } catch {}
          }
        };
        src.start();
        this._src = src;
        this._gain = gain;
        this.playing = true;
      },
      stop() {
        this._want = false;
        this.playing = false;
        try {
          const src = this._src;
          this._src = null;
          src?.stop();
        } catch {}
        return this;
      },
      pause() {
        return this.stop();
      },
      resume() {
        return this.play();
      },
      destroy() {
        this.stop();
        rt.sounds.delete(this);
      },
      fadeOut() {
        return this.stop();
      },
    };
    this.sounds.add(s);
    let f = this.scene?.o.resolve?.("sound", path, { origin: this.scene.o.origin, quiet: true });
    if (!f) f = findSound(path); // mod に無ければ funkin.assets の本体の音
    if (!f) this.warn(`FunkinSound.load("${path}"): 読み込んだ mod に音声が見つかりません（funkin.assets にもありません）`);
    else
      (async () => {
        try {
          const buf = f.arrayBuffer ? await f.arrayBuffer() : await (await f.blob()).arrayBuffer();
          const ctx = (this.actx ??= new (window.AudioContext || window.webkitAudioContext)());
          s._buf = await ctx.decodeAudioData(buf);
          s._start();
        } catch (e) {
          this.warn(`FunkinSound.load("${path}"): 音声を読み込めません（${e.message}）`);
        }
      })();
    if (autoPlay) s.play();
    return s;
  }
  /** NoteStyle の代役（スクリプトが fetchDefault() などで受け取る） */
  styleApi(st) {
    return withStubs(
      {
        id: st.id,
        getName: () => st.data?.name ?? st.id,
        getAuthor: () => st.data?.author ?? "",
        getFallbackID: () => st.data?.fallback ?? null,
        getNoteScale: () => st.getNoteScale(),
        getNoteOffsets: () => st.getNoteOffsets(),
        getHoldNoteOffsets: () => st.getHoldNoteOffsets(),
        getStrumlineOffsets: () => st.getStrumlineOffsets(),
        getStrumlineScale: () => st.getStrumlineScale(),
        fetchHoldNoteScale: () => st.fetchHoldNoteScale(),
        getNoteAssetPath: () => st.data?.assets?.note?.assetPath ?? null,
        getStrumlineAssetPath: () => st.data?.assets?.noteStrumline?.assetPath ?? null,
        getHoldNoteAssetPath: () => st.data?.assets?.holdNote?.assetPath ?? null,
        toString: () => st.id,
      },
      "NoteStyle",
      (p) => this.stub(p),
    );
  }
  /** 止める（曲が終わった・閉じたとき）: 鳴っている音とタイマーを片づける */
  stopAll() {
    for (const s of [...this.sounds]) s.stop();
    this.timers.clear();
  }
  /** 譜面の kind からノートの種類（無ければ null） */
  kindOf(id) {
    return id ? this.noteKinds.get(id) ?? null : null;
  }
  /** ノート 1 つ分の NoteSprite の代役。n は playtest のノート */
  makeNoteSprite(n, baseScale = 1) {
    const raw = {
      noteData: {
        kind: n.k ?? "",
        time: n.t,
        length: n.l,
        data: n.player ? n.lane : n.lane + 4,
        getDirection: () => n.lane,
        getMustHitNote: () => n.player,
        getStrumTime: () => n.t,
        getLength: () => n.l,
      },
      kind: n.k ?? "",
      visible: true,
      alpha: 1,
      x: 0,
      y: 0,
      scale: new Pt(1, 1),
      flipY: false,
      direction: n.lane,
      updateHitbox() {},
      flipX: false,
      angle: 0,
      antialiasing: true,
      offset: new Pt(NaN, NaN), // NaN = 既定の位置（スクリプトが set すると、その値）
      ov: { atlas: null, anims: new Map(), cur: null, t0: 0, baseScale: baseScale },
    };
    raw.scale = new Pt(baseScale, baseScale);
    Object.defineProperty(raw, "frames", { get: () => raw.ov.atlas, set: (v) => (raw.ov.atlas = v), enumerable: true });
    // FlxAnimationController の必要な分だけ（スクリプトがノートの絵を差し替えるのに使う）
    raw.animation = {
      addByPrefix: (name, prefix, fps = 24, loop = false, fx = false, fy = false) => (raw.ov.anims.set(String(name), { prefix: String(prefix), fps: Number(fps) || 24, loop: !!loop, fx, fy }), true),
      add: (name, _idx, fps = 24, loop = false) => (raw.ov.anims.set(String(name), { prefix: String(name), fps: Number(fps) || 24, loop: !!loop }), true),
      play: (name, force = false) => {
        const a = raw.ov.anims.get(String(name));
        if (!a) return;
        if (raw.ov.cur !== a || force) {
          raw.ov.cur = a;
          raw.ov.t0 = performance.now();
        }
      },
      get name() {
        return [...raw.ov.anims].find(([, a]) => a === raw.ov.cur)?.[0] ?? "";
      },
      get finished() {
        return false;
      },
    };
    n.spr = raw;
    return withStubs(raw, "NoteSprite", (p) => this.stub(p));
  }
  /** ノートのイベント（onNoteIncoming / onNoteHit / onNoteMiss / onNoteHoldDrop）。そのノートの kind と全 Module に送る。返り値は event（cancel されたか分かる） */
  noteEvent(hook, n, extra = {}) {
    const ev = { note: n.sprW ?? (n.sprW = this.makeNoteSprite(n, n.baseScale ?? 1)), holdNote: n.sprW, eventCanceled: false, cancel() { this.eventCanceled = true; }, ...extra };
    const kind = this.kindOf(n.k);
    const targets = [];
    if (kind) targets.push(kind);
    for (const m of this.modules.values()) targets.push(m);
    for (const st of this.stages) targets.push(st); // ステージのスクリプトにも届く（本物のイベント送信は、ステージやキャラも対象）
    for (const inst of targets) {
      try {
        if (inst.native) inst.native[hook]?.(ev);
        else if (this.hs.has(inst, hook)) this.hs.call(inst, hook, [ev]);
      } catch (e) {
        this.fail(`${inst.__cls?.name ?? inst.noteKind}.${hook}`, e);
      }
    }
    return ev;
  }
  hasEvent(kind) {
    return this.eventInst.has(kind);
  }
  /** 曲の読み込み通知（Module が onSongLoaded で events を見る） */
  songLoaded(events) {
    this.events = events.map((e) => this.eventData(e));
    this.broadcast("onSongLoaded", { events: this.events });
  }
  eventData(e) {
    const v = e.v && typeof e.v === "object" ? e.v : {};
    const g = (n) => (v[n] === undefined ? null : v[n]);
    return {
      time: e.t,
      eventKind: e.e,
      value: v,
      getString: (n) => (g(n) == null ? null : String(g(n))),
      getFloat: (n) => (g(n) == null ? null : Number(g(n))),
      getInt: (n) => (g(n) == null ? null : Math.trunc(Number(g(n)))),
      getBool: (n) => (g(n) == null ? null : g(n) === true || g(n) === "true"),
      getArray: (n) => g(n),
      getDynamic: (n) => g(n),
    };
  }
  broadcast(hook, ev = {}) {
    const all = [...this.eventInst.values()].map((x) => x.inst).concat([...this.modules.values()], this.stages);
    for (const inst of all) {
      if (!this.hs.has(inst, hook)) continue;
      try {
        this.hs.call(inst, hook, [ev]);
      } catch (e) {
        this.fail(`${inst.__cls.name}.${hook}`, e);
      }
    }
  }
  /** イベントを 1 つ実行する */
  fire(e) {
    if (e.e === "CustomEvent") return this.startCustom(e);
    const rec = this.eventInst.get(e.e);
    if (!rec) return false;
    try {
      this.hs.call(rec.inst, "handleEvent", [this.eventData(e)]);
    } catch (err) {
      this.fail(`イベント「${e.e}」（${(e.t / 1000).toFixed(2)}s）`, err);
    }
    return true;
  }
  // ---- CustomEvent（0.9）: 名前つきの進行イベント。Module / SongEvent の onCustomEvent(event) に 0→1 の進み具合を渡す ----
  startCustom(e) {
    const v = e.v ?? {};
    const steps = Math.max(0, Number(v.duration ?? 0));
    const tm = this.scene?.o?.timing?.();
    const startMs = e.t + Number(v.offset ?? 0);
    const endMs = steps > 0 && tm ? tm.stepToMs(tm.msToStep(startMs) + steps) : startMs;
    (this.customActive ??= []).push({ e, v, startMs, endMs, started: false });
    return true;
  }
  /** 毎フレーム: 動いている CustomEvent に進み具合を送る */
  updateCustom(pos) {
    if (!this.customActive?.length) return;
    for (const a of [...this.customActive]) {
      if (pos < a.startMs) continue;
      const dur = a.endMs - a.startMs;
      const progress = dur > 0 ? Math.min(1, (pos - a.startMs) / dur) : 1;
      const fn = easeByName(a.v.ease ?? "linear", a.v.easeDir ?? "InOut");
      const f = typeof fn === "function" ? fn : (x) => x;
      const last = progress >= 1;
      const ev = {
        eventData: this.eventData(a.e),
        name: String(a.v.name ?? ""),
        progress,
        eased: f(progress),
        elapsedMs: Math.max(0, Math.min(dur, pos - a.startMs)),
        durationMs: dur,
        isFirst: !a.started,
        isLast: last,
        isReplay: false,
        ease: (x) => f(Math.min(1, Math.max(0, x))),
        eventCanceled: false,
        cancel() {},
      };
      a.started = true;
      this.broadcast("onCustomEvent", ev);
      if (last) this.customActive = this.customActive.filter((x) => x !== a);
    }
  }
  /** 途中から始めるとき: processOldEvents のイベントを、始める位置より前の分だけ順に実行する */
  fireOld(events, startMs) {
    for (const e of events) if (e.t < startMs && this.eventInst.get(e.e)?.processOld) this.fire(e);
  }
  /** 毎フレーム: dt = 経過秒、pos = 曲の位置(ms) */
  /** ステージスクリプトを動かし始める（buildStage → onCreate）。スクリプトを全部読み込み、シーンをつないだあとに 1 回 */
  startStages() {
    for (const inst of this.stages) {
      for (const hook of ["buildStage", "addCharacters", "onCreate"]) {
        try {
          if (hook === "addCharacters") {
            // PlayState がキャラを足すたびに呼ぶ stage.addCharacter(character, type)（スクリプトが override して、キャラにシェーダーを付けるなど）
            if (this.hs.has(inst, "addCharacter"))
              for (const [fn, type] of [["getGirlfriend", "GF"], ["getDad", "DAD"], ["getBoyfriend", "BF"]]) {
                const c = this.ps[fn]?.();
                if (c) this.hs.call(inst, "addCharacter", [c, type]);
              }
          } else this.hs.call(inst, hook, hook === "onCreate" ? [{}] : []);
        } catch (e) {
          this.fail(`ステージ「${inst.stageId}」.${hook}`, e);
        }
      }
    }
  }
  update(dt, pos) {
    this.pos = pos;
    this.tweens.update(dt);
    for (const o of this.ps.members) o?.move?.(dt);
    // onUpdate（秒）と、ステップ / ビートの変わり目（onStepHit / onBeatHit）。ステージスクリプトやモジュールが受け取る
    if (this.stages.length || this.modules.size) {
      this.broadcast("onUpdate", { elapsed: dt, cancel() {}, eventCanceled: false });
      const tm = this.scene?.o?.timing?.();
      if (tm && pos >= 0) {
        const step = Math.floor(tm.msToStep(pos));
        if (this.lastStep === undefined || step < this.lastStep) this.lastStep = step;
        while (this.lastStep < step) {
          this.lastStep++;
          this.broadcast("onStepHit", { step: this.lastStep });
          if (this.lastStep % 4 === 0) this.broadcast("onBeatHit", { beat: this.lastStep / 4 });
        }
      }
    }
    this.updateCustom(pos);
    for (const t of [...this.timers]) t.step(dt);
    for (const f of this.postUpdate.slice()) {
      try {
        f();
      } catch (e) {
        this.fail("postUpdate", e);
        this.postUpdate = this.postUpdate.filter((x) => x !== f);
      }
    }
  }
  pause() {
    for (const t of this.tweens.list) t.__wasActive = t.active;
    this.broadcast("onPause", {});
  }
  resume() {
    this.broadcast("onResume", {});
  }
  /** 終了・やり直し時の後始末通知 */
  songEnd() {
    this.broadcast("onSongEnd", {});
    this.stopAll();
  }

  // ---------------------------------------------------------------- 描画
  hasContent() {
    return this.ps.members.length > 0 || Object.values(this.cams).some((c) => c.filters.length);
  }
  *objectsOf(list, cam, inherited) {
    for (const o of list) {
      if (!o || !o.exists || !o.visible) continue;
      const cams = o.cameras ?? inherited ?? [this.cams.camGame];
      if (o.members) {
        yield* this.objectsOf(o.members, cam, cams);
        continue;
      }
      if (cams.includes(cam)) yield o;
    }
  }
  /**
   * カメラ 1 枚ぶんの描画。mainCtx は CSS ピクセル座標（dpr 倍率は設定済み）。
   * @param draw { bg(ctx), hud(ctx) }  カメラごとの「基本の絵」。game に背景、hud にレーンとノーツ
   */
  render(mainCtx, W, H, dpr, draw) {
    const k = Math.min(W / GAME_W, H / GAME_H),
      ox = (W - GAME_W * k) / 2,
      oy = (H - GAME_H * k) / 2;
    Quality.tick(); // フレーム間隔が長引いたらシェーダー用の絵を縮小（自動）
    for (const cam of [this.cams.camGame, this.cams.camHUD, this.cams.camCutscene]) {
      const shaders = cam.filters.map((f) => f.shader).filter((s) => s && (s.active ? s.active() : true));
      let ctx = mainCtx;
      if (shaders.length) {
        const L = this.layerFor(cam, W, H, dpr);
        ctx = L.getContext("2d");
        ctx.setTransform(1, 0, 0, 1, 0, 0);
        ctx.clearRect(0, 0, L.width, L.height);
        const q = Math.min(1, LAYER_MAX_W / Math.max(1, W * dpr)) * Quality.scale; // 高解像度の画面ではフィルター用の絵を縮小（GPU への転送量を減らす）
        ctx.setTransform(dpr * q, 0, 0, dpr * q, 0, 0);
      }
      const shk = cam.shakeOffset(W, H);
      if (shk) {
        ctx.save();
        ctx.translate(shk[0], shk[1]);
      }
      draw.begin?.(cam.name, ctx);
      // 基本の絵 → スクリプトの表示物
      let drawn = false;
      ctx.save();
      for (const o of this.objectsOf(this.ps.members, cam, null)) {
        if (!drawn) {
          // カメラは 1280×720 の枠で切り取られる（本物と同じく、はみ出した分は見えない）
          ctx.beginPath();
          ctx.rect(ox, oy, GAME_W * k, GAME_H * k);
          ctx.clip();
          ctx.translate(ox, oy);
          ctx.scale(k, k);
          drawn = true;
        }
        if (o.alpha <= 0.002) continue;
        o.draw?.(ctx);
        ctx.globalAlpha = 1;
      }
      ctx.restore();
      draw.end?.(cam.name, ctx);
      if (shk) ctx.restore();
      for (const [col, a] of cam.overlays()) {
        if (a <= 0.002) continue;
        ctx.save();
        ctx.globalAlpha = a;
        ctx.fillStyle = col;
        ctx.fillRect(ox, oy, GAME_W * k, GAME_H * k);
        ctx.restore();
      }
      if (shaders.length) {
        let src = ctx.canvas;
        for (const sh of shaders) {
          if (!this.gl) this.gl = new GLPost();
          if (!this.gl.ok) {
            this.warn("WebGL が使えないため、シェーダー（フィルター）は無効です");
            break;
          }
          sh.onError ??= (m) => this.fail("シェーダー", Error(m));
          const out = this.gl.apply(src, sh);
          if (out) src = out;
        }
        mainCtx.save();
        mainCtx.setTransform(1, 0, 0, 1, 0, 0);
        mainCtx.globalAlpha = cam.alpha;
        if (src === this.gl?.canvas) this.gl.blit(src, mainCtx, 0, 0, Math.round(W * dpr), Math.round(H * dpr));
        else mainCtx.drawImage(src, 0, 0, Math.round(W * dpr), Math.round(H * dpr));
        mainCtx.restore();
      }
    }
  }
  layerFor(cam, W, H, dpr) {
    const q = Math.min(1, LAYER_MAX_W / Math.max(1, W * dpr)) * Quality.scale;
    const w = Math.max(1, Math.round(W * dpr * q)),
      h = Math.max(1, Math.round(H * dpr * q));
    if (!cam.layer) cam.layer = document.createElement("canvas");
    if (cam.layer.width !== w || cam.layer.height !== h) {
      cam.layer.width = w;
      cam.layer.height = h;
    }
    return cam.layer;
  }
}
